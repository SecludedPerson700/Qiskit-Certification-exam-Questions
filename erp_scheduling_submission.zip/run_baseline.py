#!/usr/bin/env python3
"""
Stage-1 baseline + Stage-2 comparison for the ERP scheduling challenge.
Produces schedule_2x2.json, schedule_3x3.json and a full comparison report.
"""
from __future__ import annotations
import json, os, time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

from src.problem import load_instances, exact_optimum, greedy_baseline, evaluate_permutation
from src.qubo import build_permutation_qubo
from src.quantum_solvers import (
    solve_cvar_qaoa, solve_lr_qaoa, solve_pce,
    classical_random_repair, run_all_methods,
)

OUT = Path("/home/workdir/artifacts/erp_scheduling")
SCHED = OUT / "schedules"
RES = OUT / "results"
SCHED.mkdir(parents=True, exist_ok=True)
RES.mkdir(parents=True, exist_ok=True)


def write_schedule(name: str, method: str, ms: int, schedule: list, path: Path):
    obj = {
        "instance": f"instance_{name}",
        "method": method,
        "makespan": int(ms),
        "schedule": schedule,
    }
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)
    print(f"Wrote {path}")


def main():
    insts = load_instances()
    summary_rows = []

    for name, inst in insts.items():
        print("\n" + "=" * 70)
        print(f"INSTANCE {name}")
        print("=" * 70)

        # --- exact & greedy ---
        opt_ms, opt_perm, opt_sched = exact_optimum(inst)
        g_ms, g_perm, g_sched = greedy_baseline(inst)
        print(f"Exact optimum : makespan={opt_ms}, perm={opt_perm}")
        print(f"Greedy        : makespan={g_ms}, perm={g_perm}")

        # --- qubit count ---
        Q, L, pairs, off, _ = build_permutation_qubo(inst)
        n_vars = len(pairs)
        print(f"Permutation QUBO variables / qubits = {n_vars}")
        print(f"(plain time-indexed at H=8 would need ~{inst.n_jobs * inst.n_machines * 8} variables)")

        # --- run all quantum + control methods (multi-seed) ---
        seeds = [7, 11, 13, 17, 19]
        all_res = run_all_methods(inst, seeds=seeds)

        # collect best quantum result for the official schedule file
        quantum_methods = [r for r in all_res if "QAOA" in r["method"] or "PCE" in r["method"]]
        best_q = min(quantum_methods, key=lambda r: (r["makespan"], r.get("opt_time", 0)))
        print(f"\nBest quantum : {best_q['method']}  makespan={best_q['makespan']}  "
              f"qubits={best_q['n_qubits']}  time={best_q.get('opt_time', 0):.2f}s")

        # write required JSON
        write_schedule(
            name, best_q["method"], best_q["makespan"], best_q["schedule"],
            SCHED / f"schedule_{name}.json",
        )

        # also keep exact for reference
        write_schedule(
            name, "Exact enumeration", opt_ms, opt_sched,
            SCHED / f"schedule_{name}_exact.json",
        )

        # --- multi-seed statistics ---
        for r in all_res:
            summary_rows.append({
                "instance": name,
                "method": r["method"],
                "seed": r.get("seed"),
                "n_qubits": r.get("n_qubits", 0),
                "makespan": r["makespan"],
                "opt_time": r.get("opt_time", 0.0),
                "gap_to_opt": r["makespan"] - opt_ms,
                "beats_greedy": r["makespan"] < g_ms,
            })

        # --- print compact table ---
        df = pd.DataFrame([s for s in summary_rows if s["instance"] == name])
        pivot = df.groupby("method").agg(
            mean_ms=("makespan", "mean"),
            best_ms=("makespan", "min"),
            mean_gap=("gap_to_opt", "mean"),
            mean_time=("opt_time", "mean"),
            qubits=("n_qubits", "first"),
        ).round(2)
        print("\nMethod comparison (multi-seed):")
        print(pivot.to_string())

    # save full summary
    sdf = pd.DataFrame(summary_rows)
    sdf.to_csv(RES / "full_comparison.csv", index=False)
    print(f"\nFull comparison saved → {RES / 'full_comparison.csv'}")

    # --- honest quantum-advantage check ---
    print("\n" + "=" * 70)
    print("HONEST QUANTUM-ADVANTAGE VERDICT")
    print("=" * 70)
    for name in ["2x2", "3x3"]:
        sub = sdf[sdf.instance == name]
        opt = sub[sub.method == "Exact (enumeration)"].makespan.iloc[0]
        greedy = sub[sub.method == "Greedy baseline"].makespan.iloc[0]
        qaoa = sub[sub.method.str.contains("QAOA")]
        pce = sub[sub.method.str.contains("PCE")]
        rand = sub[sub.method.str.contains("Random")]
        print(f"\n{name}:")
        print(f"  Exact optimum  = {opt}")
        print(f"  Greedy         = {greedy}")
        if len(qaoa):
            print(f"  CVaR/LR-QAOA   best={qaoa.makespan.min()}  mean={qaoa.makespan.mean():.1f}")
        if len(pce):
            print(f"  PCE            best={pce.makespan.min()}  mean={pce.makespan.mean():.1f}")
        if len(rand):
            print(f"  Random+decode  best={rand.makespan.min()}  mean={rand.makespan.mean():.1f}")
        # advantage only if quantum systematically beats both greedy AND random under same budget
        q_best = min(
            qaoa.makespan.min() if len(qaoa) else 999,
            pce.makespan.min() if len(pce) else 999,
        )
        r_best = rand.makespan.min() if len(rand) else 999
        if q_best < opt + 0.5 and q_best <= r_best and q_best < greedy:
            print("  → Quantum reaches optimum and matches/beats classical controls.")
        elif q_best <= r_best:
            print("  → No statistical advantage over random+decode under equal sample budget.")
        else:
            print("  → Quantum does not improve on classical controls at this size.")

    print("\nDONE. Required schedule JSON files are in", SCHED)


if __name__ == "__main__":
    main()
