# Development Log

**Project:** ERP Flow-Shop Scheduling — Quantum Hackathon  
**Team process log (UTC+2)**  
**Repository:** `erp_scheduling/`

This log is a dated running report of how the solution was built, what was tried, what was rejected, and why. It is intended to be consistent with the code in `src/`, the notebooks, and the Project Design document.

---

## 2026-10-18 — Kick-off and problem reading

**What we did**

- Read the full challenge brief (Stage 1 baseline 2×2 and 3×3; Stage 2 extension directions).
- Locked the dual service-style targets of the brief to manufacturing terms: minimise **makespan** under technological order T → F → S (T → F for Instance A).
- Confirmed output contract: `schedule_2x2.json` and `schedule_3x3.json` with integer start/end times.

**Problems**

- Time-indexed formulations explode in variables (reference ~72 binaries at horizon H = 8 for 3×3).
- Need a formulation that is both correct and small enough to run on a simulator with a clear classical reference.

**Decision**

- Treat Stage 1 as “must hit exact optimum + feasible JSON.”
- Treat Stage 2 as “shrink qubits hard, then add realism without growing the qubit count.”

---

## 2026-10-18 — Encoding choice (major design decision)

**What we did**

- Compared candidate encodings:
  1. **Time-indexed** \(x_{j,m,t}\) — standard, large.
  2. **Log / binary time encoding** — fewer bits than unary time, still horizon-dependent.
  3. **Pairwise precedence** \(x_{ij}\) (job \(i\) before job \(j\)) — size \(\binom{n}{2}\).

**Why pairwise precedence**

- For flow-shops, an optimal schedule exists that is a **permutation schedule** (same job order on every machine).
- With \(n=2\) jobs → **1** binary variable; \(n=3\) → **3** binary variables.
- Decode by topological sort always yields a total order; the classical completion-time recursion enforces machine non-overlap and route order.

**Rejected**

- **Time-indexed QUBO with slack variables** — correct but ~72 variables; contradicts the Stage-2 qubit-reduction goal.
- **One qubit per position in a permutation (one-hot)** — 9 binaries for 3 jobs with mutual-exclusion penalties; larger and messier than pairwise.
- Using exact diagonalisation of the QUBO as the “quantum solver” — would not demonstrate a variational / sampling method.

**Outcome**

- Baseline comparable number for 3×3: **3 variables** (vs 72 time-indexed; vs ~39 after simple start-window pruning in the brief).

---

## 2026-10-18 — Classical reference and QUBO construction

**What we did**

- Implemented exact enumeration of all \(n!\) permutations and Johnson / NEH-style greedy baselines (`src/problem.py`).
- Confirmed optima: makespan **4** (2×2), **8** (3×3).
- Built a slack-free QUBO by evaluating the true makespan of every bit-string after decode and fitting  
  \(E(x) = \mathrm{offset} + L^\top x + x^\top Q x\)  
  (`src/qubo.py`).

**Problems and fixes**

- First fit included diagonal quadratic terms \(x_i^2\); for binary \(x_i\) these are redundant with linear terms and made the design matrix rank-deficient. **Fix:** fit only offset, linear, and \(i<j\) quadratic monomials.
- Residual \(O(0.25)\) remains on 3 variables because a general function on \(\{0,1\}^3\) has cubic terms. **Acceptable:** exhaustive check shows QUBO ground states still decode to optimal permutations.

**Decision**

- Prefer a QUBO whose **argmin** is correct over a perfect energy fit on infeasible or non-quadratic structure.

---

## 2026-10-18 — Quantum methods (from staffing notebooks)

**What we did**

- Ported the same hybrid stack used in the call-centre notebooks into `src/quantum_solvers.py`:
  - **Warm-start** (Egger-style): greedy bits → \(R_Y(\theta)\) preparation + biased mixer.
  - **CVaR-QAOA**: optimise CVaR\(_{\alpha=0.25}\) of sampled energies (COBYLA).
  - **LR-QAOA**: optimise plain shot-weighted expectation with parameters \((\gamma,\beta)\).
  - **PCE**: 3 classical bits → 2 qubits via weight-≤2 Z/ZZ correlators, EfficientSU2, soft bits \(\frac12(1-\tanh(\alpha\langle P\rangle))\), sign decode.
- Added a **random + decode** control arm with the same sample budget.

**Problems**

- Qiskit EstimatorV2 returns 0-d arrays for single observables; PCE soft-bit extraction needed an explicit reshape.
- Package `__init__` imported quantum solvers eagerly and broke classical-only imports when qiskit was missing. **Fix:** lazy `__getattr__` import.

**Decision**

- Keep \(p=1\) QAOA layers and few COBYLA iterations — consistent with small qubit counts and the staffing notebooks.
- Always score schedules with the classical makespan evaluator, never trust QUBO energy alone for the final report.

---

## 2026-10-18 — Multi-seed verification and honest advantage analysis

**What we did**

- Ran seeds \(\{7,11,13,17,19\}\) for CVaR-QAOA, LR-QAOA, PCE (3×3), and random.
- Every quantum method recovered makespan 4 / 8 on every seed.
- Wrote required JSON schedules; checked machine non-overlap and T→F→S order.

**Finding**

- Random + decode also hits the optimum under the same budget.
- **No statistical quantum advantage** at 1–3 qubits. The value is the **encoding**, not the circuit.

**Rejected**

- Claiming “quantum beats greedy” without the random control (greedy is already optimal here; the fair control is random search with equal samples).

---

## 2026-10-18 — Stage-2 realism extensions (separate modules)

**What we did**

- Added `src/extensions_data.py`, `extensions_qubo.py`, `extensions_solvers.py`, and `run_extensions.py`.

1. **Due dates & tardiness**  
   - Due dates e.g. Z1:6, Z2:7, Z3:9.  
   - Objective \(=\mathrm{makespan}+\lambda\sum_j\max(0,C_j-d_j)\).  
   - Same 3 pairwise bits; energy table rebuilt.  
   - Warm-start CVaR-QAOA matches exact objective on 5/5 seeds.

2. **Sequence-dependent setups**  
   - Setup matrix on (predecessor, successor, machine); milling Z1↔Z3 costs 2 h.  
   - Objective = makespan under setups.  
   - Exact optimum makespan 10; CVaR-QAOA 5/5 optimal; still 3 qubits.

3. **Second milling machine (functional scaling)**  
   - Classical what-if: F and F2 load-balancing vs single F.  
   - On this 3-job instance improvement was **0 h** (bottleneck not always on the mill). Reported honestly.

**Decision**

- Depth over count: fully formulate and verify **two** constraints rather than sketch five.
- Price of realism: extra constraints cost **zero additional qubits** in the pairwise model (vs growth in time-indexed models).

---

## 2026-10-18 — Notebooks, docs, and packaging

**What we did**

- Three executed notebooks: formulation/QUBO; warm-start CVaR & LR-QAOA; PCE + comparison + scaling + verdict.
- Project Design and this Development Log aligned with code.
- MIT `LICENSE`, README with run instructions and AI-usage note.
- Technical report PDF for submission narrative.

**Still outside the code (team process)**

- Public GitHub push and demo video remain human submission steps.

---

## Summary of decisions and rejections

| Decision | Why | Rejected alternative | Why rejected |
|----------|-----|----------------------|--------------|
| Pairwise precedence QUBO | Minimal correct size for flow-shop | Time-indexed | ~72 variables |
| Fit QUBO to true makespan table | Guarantees ground-state meaning | Hand-derived penalties only | Harder to verify |
| Warm-start CVaR / LR / PCE | Match proven staffing stack | Pure cold-start VQE | Weaker on tiny instances |
| Random control arm | Honest advantage test | Only vs greedy | Greedy already optimal |
| Tardiness + setups on same bits | Realism without qubit growth | New slack qubits per constraint | Unnecessary |
| Report 0 h dual-mill gain | Honesty | Inflating benefit | Would break consistency |

---

## AI usage (process)

LLM tools were used for scaffolding, API reminders, and drafting documentation. Modelling choices (pairwise encoding, residual acceptance, control-arm design, extension objectives), verification against exact enumeration, and the no-advantage conclusion were made and checked by the team against runnable code.
