# Project Design

**Project:** ERP Production Scheduling Optimization (Quantum Hackathon)  
**Scope:** Stage 1 baseline (2×2, 3×3) + Stage 2 extensions (qubit reduction, algorithm comparison, due dates, sequence-dependent setups, functional scaling)

---

## 1. What is the optimisation problem?

**Problem class:** Flow-shop scheduling (special case of job-shop): every job visits the same machines in the same technological order.

**Instance A (2×2):** jobs Z1, Z2; machines T (lathe), F (mill); order T → F.  
**Instance B (3×3):** jobs Z1, Z2, Z3; machines T, F, S (weld); order T → F → S.

**Baseline objective:** minimise **makespan** — completion time of the last operation of the last job.

**Stage-2 objectives (same decision variables):**

- Makespan + weighted total **tardiness** against per-job due dates.
- Makespan under **sequence-dependent setup times** on machines.
- Classical what-if: second milling machine (F2) load-balancing (functional scaling).

**Constraints (baseline):**

- Each operation starts once.
- No two operations occupy the same machine at the same time.
- Operations of a job respect T → F → S (or T → F).

---

## 2. State representation, variables, and parameters

### 2.1 Decision variables (pairwise precedence)

For \(n\) jobs labelled \(0,\ldots,n-1\):

\[
x_{ij}\in\{0,1\},\qquad i<j,
\]

with interpretation

\[
x_{ij}=1 \;\Leftrightarrow\; \text{job }i\text{ precedes job }j\text{ on every machine}.
\]

| Instance | \(n\) | Number of variables | vs time-indexed (H≈8) |
|----------|-------|---------------------|------------------------|
| 2×2 | 2 | **1** | ~32 |
| 3×3 | 3 | **3** | ~72 |

**Why this size:** flow-shop theory guarantees an optimal **permutation schedule** (identical job order on all machines). Encoding the order is sufficient; absolute start times are recovered classically.

### 2.2 Derived state

- Bit-string \(x\) → total order via topological sort (`decode_permutation`).
- Order → start/end times via the standard \(O(nm)\) completion-time recursion (`evaluate_permutation`).
- Makespan \(C_{\max} = \) completion of the last job on the last machine.

### 2.3 Parameters

| Symbol | Meaning | Baseline value |
|--------|---------|----------------|
| Processing times | Hours per operation | From challenge JSON |
| Technological order | Global route | T→F→S |
| Due dates \(d_j\) (extension) | Job deadlines | e.g. Z1:6, Z2:7, Z3:9 |
| Setup matrix (extension) | Extra time on changeover | e.g. 2 h on F for Z1↔Z3 |
| \(\lambda\) | Tardiness weight | 1.0 in experiments |
| Horizon \(H\) | Not a variable in our model | Implicit in recursion |

We do **not** use a discrete time horizon as a decision dimension; that is the main reason the model stays small.

---

## 3. Constraints and variable interactions

### 3.1 Hard constraints (enforced by decode + recursion)

| Constraint | How enforced |
|------------|----------------|
| Total order of jobs | Topological sort on pairwise bits |
| Machine non-overlap | Completion recursion: start ≥ previous job on same machine |
| Route order within job | Recursion: start ≥ previous operation of same job |

After decode, **every** bit-string maps to a feasible schedule. Inconsistent pairwise bits are repaired by the sort (or identity fallback); energy is always the true objective of a feasible plan.

### 3.2 Independent vs dependent quantities

- **Independent (decision):** pairwise bits \(x_{ij}\).
- **Dependent:** permutation, start/end times, makespan, tardiness, setup-augmented makespan.

### 3.3 Weights

- Baseline QUBO: energies equal true makespans (no arbitrary penalty weights for feasibility).
- Tardiness extension: \(\lambda=1\) balances hours of makespan and hours of tardiness on the same scale.
- Setups: absorbed into the simulation; no extra penalty weight.

No slack qubits are introduced.

---

## 4. QUBO model

### 4.1 Why this QUBO

We need a cost Hamiltonian for QAOA / PCE. Because \(2^{n_{\mathrm{vars}}}\) is tiny (2 or 8), we:

1. Evaluate the true objective for every bit-string after decode.
2. Fit a quadratic form  
   \[
   E(x)=\mathrm{offset}+L^\top x+x^\top Qx
   \]
   by least squares on monomials \(\{1\}\cup\{x_i\}\cup\{x_ix_j:i<j\}\).

### 4.2 Linear and quadratic terms

- **Linear \(L_i\):** bias for each pairwise precedence bit.
- **Quadratic \(Q_{ij}\):** interaction between two precedence bits (couples relative orders).
- **Offset:** constant shift.

On 3 variables a residual \(O(0.25)\) remains (non-quadratic components of a general function on the cube). Exhaustive check confirms **ground states of \(E\) still decode to optimal permutations** for baseline and extended objectives.

### 4.3 Ising map

Standard substitution \(x=(1-z)/2\) yields fields \(h\) and couplings \(J\) for RZ/RZZ cost layers in QAOA.

### 4.4 Slack-free property

Feasibility is structural (decode + recursion), not penalty-based. This matches the “slack-free dual” idea from the staffing notebooks: no extra qubits for constraint satisfaction.

---

## 5. Optimisation methods

| Method | Role | Parameters |
|--------|------|------------|
| Exact enumeration | Ground truth | All \(n!\) permutations |
| Greedy (Johnson / NEH) | Classical baseline + warm-start seed | Constructive |
| Random + decode | Control arm (equal sample budget) | Uniform bits |
| Warm-start CVaR-QAOA | Primary quantum solver | \(\alpha=0.25\), \(p=1\), COBYLA |
| Warm-start LR-QAOA | Plain-energy QAOA | \((\gamma,\beta)\), \(p=1\) |
| PCE | Correlator compression | 3 bits → 2 qubits, degree 2 |

**Warm-start:** greedy bits → \(\theta_i=2\arcsin\sqrt{v_i}\) → \(R_Y(\theta)\) prep; mixer conjugated by the same angles (Egger-style).

**CVaR:** average only the best 25% of sampled energies during training so the optimiser focuses on good bit-strings.

**PCE:** measure \(\langle Z\rangle,\langle ZZ\rangle\); soft bits via \(\tanh\); train EfficientSU2 with COBYLA; hard bits by sign rule.

Final reported makespan / tardiness / setup-makespan always comes from the **classical** evaluator, not from the QUBO residual.

---

## 6. Assumptions and simplifications

- Global technological order (not per-job routing).
- Deterministic processing times.
- Infinite buffers between machines.
- Baseline: no setups, no due dates (added in Stage-2 modules without new qubits).
- Dual-mill model is a simplified load-balance what-if (not a full second routing graph).
- Simulator only (Qiskit Aer); no hardware noise model in the reported runs.

---

## 7. Feasibility condition

A schedule is **feasible** if and only if:

1. It is a permutation schedule of the \(n\) jobs.
2. Start/end times obey the completion recursion (machine and route precedence).
3. For JSON export: `end = start + duration` for each operation.

**All decoded bit-strings satisfy (1)–(2).** Therefore the QUBO search domain is entirely feasible; the only question is optimality of the objective.

---

## 8. Stage-2 design summary

| Extension | Extra qubits | Verified |
|-----------|--------------|----------|
| Pairwise vs time-indexed reduction | 72 → 3 (PCE → 2) | Yes |
| Algorithm comparison + multi-seed | — | Yes |
| Due dates / tardiness | **0** | Yes (exact match 5/5) |
| Sequence-dependent setups | **0** | Yes (exact match 5/5) |
| Second mill cost-benefit | Classical | Yes (0 h gain on this instance) |

**Comparable number for baseline 3×3:** **3** binary variables (smallest correct QUBO used in this work).

---

## 9. Consistency with code

| Design element | Code location |
|----------------|---------------|
| Instances, makespan, exact/greedy | `src/problem.py` |
| Pairwise QUBO, decode, Ising | `src/qubo.py` |
| CVaR / LR / PCE / random | `src/quantum_solvers.py` |
| Due dates, setups, dual mill | `src/extensions_data.py` |
| Extended QUBOs | `src/extensions_qubo.py` |
| Extended solvers | `src/extensions_solvers.py` |
| Baseline runner | `run_baseline.py` |
| Extension runner | `run_extensions.py` |
| Notebooks 1–3 | `notebooks/` |
