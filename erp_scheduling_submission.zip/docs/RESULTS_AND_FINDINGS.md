# Results, Methods & Findings (Verified Re-run)  
## Quantum Hackathon – Production Scheduling Optimization (ERP)

**Verification date:** 2026-10-18  
**All numbers below come from a fresh multi-seed re-run (seeds 7, 11, 13, 17, 19).**

---

## 1. Methods – fidelity to the staffing notebooks

| Method | Notebook pattern used | How it is implemented here | Status |
|--------|----------------------|----------------------------|--------|
| **Slack-free QUBO** | Quadratic shortfall / unconstrained encoding (no extra slack qubits) | Pairwise precedence bits only; decode always yields a feasible permutation → **no slack variables** | Correct |
| **Warm-start** | Egger-style RY biased preparation + biased mixer (from CVaR / hybrid notebooks) | Classical greedy bit-string → `θ_i = 2 arcsin√v_i` → RY(θ) prep; mixer = RY(−θ) RZ(−2β) RY(+θ) | Correct |
| **CVaR-QAOA** | Optimise CVaR_α of sampled energies (α = 0.25) instead of mean | Sample circuit → sort energies → average best 25 % → COBYLA | Correct |
| **LR-QAOA** | Linear-ramp / plain-expectation QAOA with 2 parameters (γ, β) | Same warm-start circuit; objective = shot-weighted mean energy | Correct |
| **PCE** | Pauli Correlation Encoding: N classical vars → O(log N) qubits via Z/ZZ correlators, soft bits, EfficientSU2 + COBYLA | 3 classical bits → 2 qubits, weight-≤2 Paulis, `x_soft = ½(1−tanh(α⟨P⟩))`, sign decode | Correct |

All five techniques appear in the call-centre notebooks you supplied and are reused faithfully for the flow-shop QUBO.

---

## 2. Stage-1 baseline results (verified)

| Instance | Exact optimum | Warm-start CVaR-QAOA | Warm-start LR-QAOA | PCE (2 qubits) | Greedy | Random + decode | Gap |
|----------|---------------|----------------------|--------------------|----------------|--------|-----------------|-----|
| **2×2** | **4** | **4** (5/5 seeds) | **4** (5/5) | — | 4 | 4 (5/5) | **0** |
| **3×3** | **8** | **8** (5/5 seeds) | **8** (5/5) | **8** (5/5) | 8 | 8 (5/5) | **0** |

Required JSON files (rewritten after this verification run):

| File | Makespan | Method | Feasible |
|------|----------|--------|----------|
| `schedules/schedule_2x2.json` | 4 | Warm-start CVaR-QAOA | Yes |
| `schedules/schedule_3x3.json` | 8 | Warm-start CVaR-QAOA | Yes |

Feasibility checks performed: machine non-overlap and technological order T→F→S both hold for every quantum schedule.

---

## 3. Qubits used

| Instance | Encoding | Qubits | Plain time-indexed (H≈8) | Reduction |
|----------|----------|--------|---------------------------|-----------|
| 2×2 | Pairwise precedence | **1** | ~32 | **~32×** |
| 3×3 | Pairwise precedence | **3** | ~72 | **~24×** |
| 3×3 | PCE compression | **2** | ~72 | **~36×** |

Encoding: binary variables \(x_{ij}\) (i < j) with \(x_{ij}=1\) ⇔ job i precedes job j.  
Decode by topological sort → always a feasible permutation schedule.  
No slack qubits.

---

## 4. Full multi-seed comparison table

| Instance | Method | Best MS | Mean MS | Mean time (s) | Qubits | Optimal runs |
|----------|--------|---------|---------|---------------|--------|--------------|
| 2×2 | Exact (enumeration) | 4 | 4.0 | 0.000 | 0 | 1/1 |
| 2×2 | Greedy baseline | 4 | 4.0 | 0.000 | 0 | 1/1 |
| 2×2 | Warm-start CVaR-QAOA | 4 | 4.0 | 0.032 | 1 | **5/5** |
| 2×2 | Warm-start LR-QAOA | 4 | 4.0 | 0.086 | 1 | **5/5** |
| 2×2 | Random + decode | 4 | 4.0 | 0.001 | 0 | 5/5 |
| 3×3 | Exact (enumeration) | 8 | 8.0 | 0.000 | 0 | 1/1 |
| 3×3 | Greedy baseline | 8 | 8.0 | 0.000 | 0 | 1/1 |
| 3×3 | Warm-start CVaR-QAOA | 8 | 8.0 | 0.054 | 3 | **5/5** |
| 3×3 | Warm-start LR-QAOA | 8 | 8.0 | 0.123 | 3 | **5/5** |
| 3×3 | PCE (n_q=2, D=2) | 8 | 8.0 | 0.219 | 2 | **5/5** |
| 3×3 | Random + decode | 8 | 8.0 | 0.001 | 0 | 5/5 |

CSV: `results/verified_comparison.csv`

---

## 5. Scaling of the permutation encoding

| # jobs | Pairwise qubits | PCE (degree-2, approx.) | Time-indexed (rough) | Classical permutations |
|--------|-----------------|-------------------------|----------------------|------------------------|
| 2 | 1 | 1 | ~50 | 2 |
| 3 | 3 | 2 | ~100 | 6 |
| 4 | 6 | 3–4 | ~200 | 24 |
| 5 | 10 | 4–5 | ~300 | 120 |
| 6 | 15 | 5–6 | ~400 | 720 |
| 8 | 28 | 7–8 | ~800 | 40 320 |
| 10 | 45 | 9–10 | ~1 200 | 3.6 M |

Exact classical enumeration becomes expensive beyond ~10–12 jobs; that is the regime where the quantum sampler can start to matter.

---

## 6. Stage-2 extension summary

What was delivered beyond the mandatory baseline:

1. **Qubit reduction** – 72 → 3 (or 2 with PCE).  
2. **Full algorithm suite** from the staffing notebooks: slack-free QUBO, warm-start, CVaR-QAOA, LR-QAOA, PCE.  
3. **Multi-seed statistics** + classical control arm (random + decode).  
4. **Verified feasibility** of every returned schedule.  
5. **Honest advantage analysis** (see below).

---

## 7. Honest quantum-advantage verdict

| Question | Answer |
|----------|--------|
| Do the quantum methods solve Stage 1 correctly? | **Yes** – makespan 4 and 8 on every seed. |
| Are the notebook techniques used correctly? | **Yes** – slack-free QUBO, warm-start, CVaR, LR-QAOA, PCE all match the patterns in the supplied notebooks. |
| Is there a statistical quantum advantage on these instances? | **No.** Random + decode recovers the same optimum under equal sample budgets. |
| Why? | Search space is tiny (2 and 6 permutations). The value is the compact encoding, not the quantum circuit. |
| Where could advantage appear? | Larger permutation problems (n ≳ 10–12) where classical enumeration fails. |

---

## 8. Artefacts

```
erp_scheduling/
├── schedules/
│   ├── schedule_2x2.json          ← Stage-1 deliverable (makespan 4)
│   └── schedule_3x3.json          ← Stage-1 deliverable (makespan 8)
├── results/
│   ├── verified_comparison.csv
│   ├── full_comparison.csv
│   ├── gantt_2x2.png
│   └── gantt_3x3.png
├── docs/
│   ├── PROJECT_DESIGN.md
│   ├── DEVELOPMENT_LOG.md
│   └── RESULTS_AND_FINDINGS.md    ← this file
├── src/
│   ├── problem.py
│   ├── qubo.py                    ← slack-free pairwise QUBO
│   └── quantum_solvers.py         ← CVaR / LR / PCE / warm-start
├── run_baseline.py
└── README.md
```

**Bottom line (verified):**  
Stage 1 is solved optimally.  
All five notebook techniques (slack-free QUBO, warm-start, CVaR-QAOA, LR-QAOA, PCE) are implemented correctly and recover the exact optimum on every seed.  
No statistical quantum advantage appears at 1–3 qubits; the main contribution is the minimal correct formulation and the clear scaling path.
