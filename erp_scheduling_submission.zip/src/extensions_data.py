"""
Stage-2 extended factory data: due dates, sequence-dependent setups,
and a hypothetical second milling machine scenario.

All numbers are chosen so the extended problems remain small enough
for exact classical verification while still demonstrating the cost
of realism in both time-indexed and pairwise encodings.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional
import copy

from .problem import (
    Instance, Job, Operation, MACHINE_ORDER,
    INSTANCE_2X2, INSTANCE_3X3, load_instances, evaluate_permutation,
)


# ---------------------------------------------------------------------------
# Due dates (per job) — Stage-2 extension
# ---------------------------------------------------------------------------
# Tight enough that some permutations incur positive tardiness.
DUE_DATES_3X3: Dict[str, int] = {
    "Z1": 6,   # tight
    "Z2": 7,
    "Z3": 9,   # looser
}

DUE_DATES_2X2: Dict[str, int] = {
    "Z1": 4,
    "Z2": 3,
}


def job_completion_times(inst: Instance, perm: List[str]) -> Dict[str, int]:
    """Completion time of each job's last operation under a permutation schedule."""
    job_map = {j.id: j for j in inst.jobs}
    n, m = len(perm), inst.n_machines
    C = [[0] * m for _ in range(n)]
    for i, jid in enumerate(perm):
        job = job_map[jid]
        for k, op in enumerate(job.ops):
            prev_job = C[i - 1][k] if i > 0 else 0
            prev_op = C[i][k - 1] if k > 0 else 0
            C[i][k] = max(prev_job, prev_op) + op.duration
    return {perm[i]: C[i][-1] for i in range(n)}


def total_tardiness(inst: Instance, perm: List[str], due: Dict[str, int]) -> int:
    comp = job_completion_times(inst, perm)
    return sum(max(0, comp[j] - due[j]) for j in perm)


def makespan_and_tardiness(
    inst: Instance, perm: List[str], due: Dict[str, int]
) -> Tuple[int, int, List[dict]]:
    ms, sched = evaluate_permutation(inst, perm)
    tard = total_tardiness(inst, perm, due)
    return ms, tard, sched


# ---------------------------------------------------------------------------
# Sequence-dependent setup times — Stage-2 extension
# ---------------------------------------------------------------------------
# setup[(pred_job, succ_job, machine)] = extra hours when switching.
# Same job type consecutive → 0 (not applicable for distinct jobs, but
# we still encode the structure).

def default_setups_3x3() -> Dict[Tuple[str, str, str], int]:
    """
    Symmetric-ish setup matrix: switching between Z1 and Z3 is expensive
    on the mill (F); other pairs are cheap.
    """
    jobs = ["Z1", "Z2", "Z3"]
    machines = ["T", "F", "S"]
    setups = {}
    for a in jobs:
        for b in jobs:
            if a == b:
                continue
            for m in machines:
                if m == "F" and {a, b} == {"Z1", "Z3"}:
                    setups[(a, b, m)] = 2
                elif m == "F":
                    setups[(a, b, m)] = 1
                else:
                    setups[(a, b, m)] = 0
    return setups


def evaluate_permutation_with_setups(
    inst: Instance,
    perm: List[str],
    setups: Dict[Tuple[str, str, str], int],
) -> Tuple[int, List[dict]]:
    """
    Same recursion as evaluate_permutation, but each machine adds a setup
    delay when the previous job on that machine differs.
    """
    job_map = {j.id: j for j in inst.jobs}
    n, m = len(perm), inst.n_machines
    machines = inst.machines
    C = [[0] * m for _ in range(n)]
    schedule = []
    # last job processed on each machine
    last_job_on_m = [None] * m

    for i, jid in enumerate(perm):
        job = job_map[jid]
        for k, op in enumerate(job.ops):
            prev_job_time = C[i - 1][k] if i > 0 else 0
            prev_op_time = C[i][k - 1] if k > 0 else 0
            setup = 0
            if last_job_on_m[k] is not None:
                setup = setups.get((last_job_on_m[k], jid, op.machine), 0)
            start = max(prev_job_time, prev_op_time) + setup
            # if setup was applied after prev_job_time, need care:
            # machine free time is prev_job_time; setup starts then
            machine_ready = prev_job_time
            if last_job_on_m[k] is not None:
                machine_ready = prev_job_time + setups.get(
                    (last_job_on_m[k], jid, op.machine), 0
                )
            start = max(machine_ready, prev_op_time)
            end = start + op.duration
            C[i][k] = end
            last_job_on_m[k] = jid
            schedule.append({
                "job": jid,
                "machine": op.machine,
                "start": int(start),
                "end": int(end),
                "setup_before": int(start - max(prev_job_time if i > 0 else 0, prev_op_time)
                                    if False else 0),  # filled below
            })
    # recompute setup_before cleanly
    schedule = []
    last_job_on_m = [None] * m
    C = [[0] * m for _ in range(n)]
    for i, jid in enumerate(perm):
        job = job_map[jid]
        for k, op in enumerate(job.ops):
            prev_job_time = C[i - 1][k] if i > 0 else 0
            prev_op_time = C[i][k - 1] if k > 0 else 0
            su = 0
            if last_job_on_m[k] is not None:
                su = setups.get((last_job_on_m[k], jid, op.machine), 0)
            machine_ready = prev_job_time + su
            start = max(machine_ready, prev_op_time)
            end = start + op.duration
            C[i][k] = end
            last_job_on_m[k] = jid
            schedule.append({
                "job": jid,
                "machine": op.machine,
                "start": int(start),
                "end": int(end),
                "setup": int(su),
            })
    makespan = int(C[-1][-1])
    return makespan, schedule


# ---------------------------------------------------------------------------
# Functional scaling: second milling machine (F2)
# ---------------------------------------------------------------------------
def instance_with_second_mill() -> Instance:
    """
    MetalTech considers a second milling machine F2.
    Model: jobs may use F or F2 (same duration); we still force a single
    global order but allow parallel milling by assigning alternate jobs
    to F2 in the evaluation (simplified: odd positions on F2).

    For a fair cost-benefit we keep the same 3 jobs / 3-step route but
    split the milling resource — evaluated classically by trying both
    'all on F' vs 'load-balanced F/F2' under the same permutation.
    """
    # Return the standard 3x3; evaluation logic lives in functional_scaling.py
    return load_instances()["3x3"]


def evaluate_with_two_mills(inst: Instance, perm: List[str]) -> Tuple[int, List[dict]]:
    """
    Simplified dual-mill model: milling operations of consecutive jobs
    in the permutation can overlap (F and F2). Turning and welding stay
    single-machine.
    """
    job_map = {j.id: j for j in inst.jobs}
    n = len(perm)
    # indices: T=0, F=1, S=2
    # track free time on T, F, F2, S
    free_T, free_F, free_F2, free_S = 0, 0, 0, 0
    schedule = []
    for i, jid in enumerate(perm):
        job = job_map[jid]
        # T
        dur_T = job.ops[0].duration
        start_T = free_T
        end_T = start_T + dur_T
        free_T = end_T
        schedule.append({"job": jid, "machine": "T", "start": start_T, "end": end_T})
        # F or F2: assign to whichever is free earlier (after T done)
        dur_F = job.ops[1].duration
        ready = end_T
        if free_F <= free_F2:
            start_F = max(ready, free_F)
            end_F = start_F + dur_F
            free_F = end_F
            mill = "F"
        else:
            start_F = max(ready, free_F2)
            end_F = start_F + dur_F
            free_F2 = end_F
            mill = "F2"
        schedule.append({"job": jid, "machine": mill, "start": start_F, "end": end_F})
        # S
        dur_S = job.ops[2].duration
        start_S = max(end_F, free_S)
        end_S = start_S + dur_S
        free_S = end_S
        schedule.append({"job": jid, "machine": "S", "start": start_S, "end": end_S})
    makespan = max(s["end"] for s in schedule)
    return makespan, schedule
