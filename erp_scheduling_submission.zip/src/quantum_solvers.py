"""
Quantum solvers for the permutation QUBO:
  - Warm-started CVaR-QAOA
  - Linear-Ramp QAOA (plain energy)
  - Pauli Correlation Encoding (PCE) hybrid (when #vars > #qubits)
  - Classical brute-force / random + repair baselines
"""
from __future__ import annotations
import numpy as np
from typing import Dict, List, Tuple, Optional, Callable
from scipy.optimize import minimize
import time

# Qiskit
from qiskit import QuantumCircuit
from qiskit.circuit.library import efficient_su2
from qiskit.quantum_info import SparsePauliOp
from qiskit_aer.primitives import EstimatorV2 as AerEstimator, SamplerV2 as AerSampler

from .qubo import (
    build_permutation_qubo, qubo_energy, qubo_to_ising,
    decode_permutation, pairwise_vars,
)
from .problem import Instance, evaluate_permutation, exact_optimum, greedy_baseline


# ---------------------------------------------------------------------------
# Helper: sample bitstrings from a circuit
# ---------------------------------------------------------------------------
def sample_circuit(qc: QuantumCircuit, shots: int = 1024) -> Dict[str, int]:
    sampler = AerSampler()
    job = sampler.run([qc], shots=shots)
    result = job.result()
    # SamplerV2 returns BitArray
    counts = result[0].data.meas.get_counts()
    return counts


def counts_to_best(counts: Dict[str, int], n_vars: int, eval_fn: Callable) -> Tuple[np.ndarray, float]:
    """Return lowest-energy bitstring among measured ones."""
    best_x, best_e = None, float("inf")
    for bitstr, cnt in counts.items():
        # Qiskit returns little-endian
        bits = np.array([int(b) for b in bitstr[::-1][:n_vars]], dtype=float)
        e = eval_fn(bits)
        if e < best_e:
            best_e = e
            best_x = bits
    return best_x, best_e


# ---------------------------------------------------------------------------
# Warm-start state preparation
# ---------------------------------------------------------------------------
def warm_start_angles(x0: np.ndarray, eps: float = 0.1) -> np.ndarray:
    """Map classical bits to RY angles (biased superposition)."""
    # theta = 2 arcsin(sqrt(v)) with v clipped away from 0/1
    v = np.clip(x0, eps, 1 - eps)
    return 2 * np.arcsin(np.sqrt(v))


def build_warm_start_qaoa(
    h: np.ndarray,
    J: np.ndarray,
    x0: np.ndarray,
    p: int = 1,
) -> QuantumCircuit:
    """
    Warm-started QAOA circuit (Egger et al. style):
      - RY(theta_i) preparation from classical solution
      - cost unitary (RZ / RZZ)
      - biased mixer conjugated by the same RY
    """
    n = len(h)
    theta = warm_start_angles(x0)
    qc = QuantumCircuit(n)

    # preparation
    for i in range(n):
        qc.ry(theta[i], i)

    for layer in range(p):
        # cost
        for i in range(n):
            if abs(h[i]) > 1e-12:
                qc.rz(2 * h[i], i)          # gamma absorbed later
        for i in range(n):
            for j in range(i + 1, n):
                if abs(J[i, j]) > 1e-12:
                    qc.rzz(2 * J[i, j], i, j)
        # mixer (biased)
        for i in range(n):
            qc.ry(-theta[i], i)
            qc.rz(-2.0, i)                  # beta absorbed later
            qc.ry(theta[i], i)
    qc.measure_all()
    return qc


def assign_qaoa_params(qc: QuantumCircuit, gamma: float, beta: float, p: int = 1) -> QuantumCircuit:
    """Bind linear-ramp or single (gamma, beta) parameters by scaling the angles already present."""
    # The circuit was built with unit coefficients; we scale by replacing the parameters.
    # Simpler: rebuild with scaled coefficients.
    return qc  # placeholder – we rebuild below


def qaoa_circuit_with_params(
    h: np.ndarray, J: np.ndarray, x0: np.ndarray,
    gamma: float, beta: float, p: int = 1,
) -> QuantumCircuit:
    n = len(h)
    theta = warm_start_angles(x0)
    qc = QuantumCircuit(n)
    for i in range(n):
        qc.ry(theta[i], i)
    for _ in range(p):
        for i in range(n):
            if abs(h[i]) > 1e-12:
                qc.rz(2 * gamma * h[i], i)
        for i in range(n):
            for j in range(i + 1, n):
                if abs(J[i, j]) > 1e-12:
                    qc.rzz(2 * gamma * J[i, j], i, j)
        for i in range(n):
            qc.ry(-theta[i], i)
            qc.rz(-2 * beta, i)
            qc.ry(theta[i], i)
    qc.measure_all()
    return qc


# ---------------------------------------------------------------------------
# CVaR objective
# ---------------------------------------------------------------------------
def cvar_from_counts(counts: Dict[str, int], n_vars: int, eval_fn: Callable, alpha: float = 0.25) -> float:
    energies = []
    total = sum(counts.values())
    for bitstr, cnt in counts.items():
        bits = np.array([int(b) for b in bitstr[::-1][:n_vars]], dtype=float)
        e = eval_fn(bits)
        energies.extend([e] * cnt)
    energies = np.sort(energies)
    k = max(1, int(np.ceil(alpha * len(energies))))
    return float(np.mean(energies[:k]))


# ---------------------------------------------------------------------------
# Solver entry points
# ---------------------------------------------------------------------------
def solve_cvar_qaoa(
    inst: Instance,
    p: int = 1,
    alpha: float = 0.25,
    shots: int = 512,
    maxiter: int = 30,
    seed: int = 7,
) -> Dict:
    np.random.seed(seed)
    Q, L, pairs, offset, energies = build_permutation_qubo(inst)
    n_vars = len(pairs)
    h, J, const = qubo_to_ising(Q, L, offset)
    job_ids = [j.id for j in inst.jobs]

    def energy_fn(x):
        return qubo_energy(x, Q, L, offset)

    # classical warm-start from greedy
    g_ms, g_perm, _ = greedy_baseline(inst)
    # encode greedy perm into pairwise bits
    pos = {jid: i for i, jid in enumerate(g_perm)}
    x0 = np.zeros(n_vars)
    for k, (i, j) in enumerate(pairs):
        # bit = 1 if job_ids[i] precedes job_ids[j]
        x0[k] = 1.0 if pos[job_ids[i]] < pos[job_ids[j]] else 0.0

    def objective(params):
        gamma, beta = params
        qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
        counts = sample_circuit(qc, shots=shots)
        return cvar_from_counts(counts, n_vars, energy_fn, alpha)

    # linear-ramp style initial guess
    x_init = np.array([0.5, 0.5])
    t0 = time.time()
    res = minimize(objective, x_init, method="COBYLA", options={"maxiter": maxiter})
    t_opt = time.time() - t0

    # final sample
    gamma, beta = res.x
    qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
    counts = sample_circuit(qc, shots=shots * 2)
    best_x, best_e = counts_to_best(counts, n_vars, energy_fn)
    perm = decode_permutation(best_x, job_ids)
    ms, schedule = evaluate_permutation(inst, perm)

    return {
        "method": "Warm-start CVaR-QAOA",
        "n_qubits": n_vars,
        "makespan": ms,
        "perm": perm,
        "schedule": schedule,
        "energy": best_e,
        "opt_time": t_opt,
        "params": {"gamma": float(gamma), "beta": float(beta)},
        "counts": counts,
        "seed": seed,
    }


def solve_lr_qaoa(
    inst: Instance,
    p: int = 1,
    shots: int = 512,
    maxiter: int = 30,
    seed: int = 7,
) -> Dict:
    """Linear-Ramp QAOA optimising plain expectation value."""
    np.random.seed(seed)
    Q, L, pairs, offset, energies = build_permutation_qubo(inst)
    n_vars = len(pairs)
    h, J, const = qubo_to_ising(Q, L, offset)
    job_ids = [j.id for j in inst.jobs]

    def energy_fn(x):
        return qubo_energy(x, Q, L, offset)

    g_ms, g_perm, _ = greedy_baseline(inst)
    pos = {jid: i for i, jid in enumerate(g_perm)}
    x0 = np.zeros(n_vars)
    for k, (i, j) in enumerate(pairs):
        x0[k] = 1.0 if pos[job_ids[i]] < pos[job_ids[j]] else 0.0

    def expectation(params):
        gamma, beta = params
        qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
        counts = sample_circuit(qc, shots=shots)
        total = sum(counts.values())
        e = 0.0
        for bitstr, cnt in counts.items():
            bits = np.array([int(b) for b in bitstr[::-1][:n_vars]], dtype=float)
            e += energy_fn(bits) * cnt
        return e / total

    x_init = np.array([0.5, 0.5])
    t0 = time.time()
    res = minimize(expectation, x_init, method="COBYLA", options={"maxiter": maxiter})
    t_opt = time.time() - t0

    gamma, beta = res.x
    qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
    counts = sample_circuit(qc, shots=shots * 2)
    best_x, best_e = counts_to_best(counts, n_vars, energy_fn)
    perm = decode_permutation(best_x, job_ids)
    ms, schedule = evaluate_permutation(inst, perm)

    return {
        "method": "Warm-start LR-QAOA",
        "n_qubits": n_vars,
        "makespan": ms,
        "perm": perm,
        "schedule": schedule,
        "energy": best_e,
        "opt_time": t_opt,
        "params": {"gamma": float(gamma), "beta": float(beta)},
        "counts": counts,
        "seed": seed,
    }


def solve_pce(
    inst: Instance,
    n_qubits: int = 2,
    degree: int = 2,
    shots: int = 512,
    maxiter: int = 40,
    seed: int = 7,
) -> Dict:
    """
    Pauli Correlation Encoding – compress n_vars classical bits into n_qubits
    using weight-≤degree Z/ZZ correlators (same idea as the staffing PCE notebook).
    """
    np.random.seed(seed)
    Q, L, pairs, offset, energies = build_permutation_qubo(inst)
    n_vars = len(pairs)
    job_ids = [j.id for j in inst.jobs]

    # assign Pauli strings
    from itertools import combinations as comb
    paulis = []
    for d in range(1, degree + 1):
        for idxs in comb(range(n_qubits), d):
            label = ["I"] * n_qubits
            for i in idxs:
                label[i] = "Z"
            paulis.append("".join(label))
            if len(paulis) >= n_vars:
                break
        if len(paulis) >= n_vars:
            break
    paulis = paulis[:n_vars]

    # EfficientSU2 ansatz
    ansatz = efficient_su2(n_qubits, reps=2, entanglement="linear")
    n_params = ansatz.num_parameters

    estimator = AerEstimator()

    def soft_bits(theta):
        qc = ansatz.assign_parameters(theta)
        ops = [SparsePauliOp(p) for p in paulis]
        job = estimator.run([(qc, op) for op in ops])
        res = job.result()
        expvals = np.array([
            float(np.asarray(res[i].data.evs).reshape(-1)[0])
            for i in range(len(paulis))
        ])
        alpha = 2.0
        return 0.5 * (1.0 - np.tanh(alpha * expvals))

    def loss(theta):
        xsoft = soft_bits(theta)
        return qubo_energy(xsoft, Q, L, offset)

    theta0 = np.random.uniform(-np.pi, np.pi, n_params)
    t0 = time.time()
    res = minimize(loss, theta0, method="COBYLA", options={"maxiter": maxiter})
    t_opt = time.time() - t0

    xsoft = soft_bits(res.x)
    xhard = (xsoft < 0.5).astype(float)  # sign rule
    perm = decode_permutation(xhard, job_ids)
    ms, schedule = evaluate_permutation(inst, perm)

    return {
        "method": f"PCE (n_q={n_qubits}, D={degree})",
        "n_qubits": n_qubits,
        "n_vars": n_vars,
        "makespan": ms,
        "perm": perm,
        "schedule": schedule,
        "energy": float(qubo_energy(xhard, Q, L, offset)),
        "opt_time": t_opt,
        "seed": seed,
    }


def classical_random_repair(inst: Instance, n_samples: int = 64, seed: int = 7) -> Dict:
    """Control arm: random bitstrings + decode (same budget as quantum)."""
    np.random.seed(seed)
    Q, L, pairs, offset, _ = build_permutation_qubo(inst)
    n_vars = len(pairs)
    job_ids = [j.id for j in inst.jobs]
    best_ms, best_perm, best_sched = float("inf"), None, None
    t0 = time.time()
    for _ in range(n_samples):
        bits = np.random.randint(0, 2, n_vars).astype(float)
        perm = decode_permutation(bits, job_ids)
        ms, sched = evaluate_permutation(inst, perm)
        if ms < best_ms:
            best_ms, best_perm, best_sched = ms, perm, sched
    return {
        "method": "Random + decode",
        "n_qubits": 0,
        "makespan": best_ms,
        "perm": best_perm,
        "schedule": best_sched,
        "opt_time": time.time() - t0,
        "seed": seed,
    }


def run_all_methods(inst: Instance, seeds: List[int] = [7, 11, 13, 17, 19]) -> List[Dict]:
    results = []
    # classical references
    opt_ms, opt_perm, opt_sched = exact_optimum(inst)
    results.append({
        "method": "Exact (enumeration)",
        "n_qubits": 0,
        "makespan": opt_ms,
        "perm": opt_perm,
        "schedule": opt_sched,
        "opt_time": 0.0,
        "seed": None,
    })
    g_ms, g_perm, g_sched = greedy_baseline(inst)
    results.append({
        "method": "Greedy baseline",
        "n_qubits": 0,
        "makespan": g_ms,
        "perm": g_perm,
        "schedule": g_sched,
        "opt_time": 0.0,
        "seed": None,
    })

    for s in seeds:
        results.append(solve_cvar_qaoa(inst, seed=s))
        results.append(solve_lr_qaoa(inst, seed=s))
        # PCE only useful when we artificially compress; for 3 vars we keep n_q=2
        if inst.n_jobs >= 3:
            results.append(solve_pce(inst, n_qubits=2, degree=2, seed=s))
        results.append(classical_random_repair(inst, seed=s))
    return results
