"""
Minimal-qubit permutation QUBO for flow-shop scheduling.

For n jobs we introduce binary variables x_{ij} (i < j) that encode
whether job i precedes job j on every machine.

Number of variables:
  2 jobs → 1 bit
  3 jobs → 3 bits
  4 jobs → 6 bits
  …

Objective = makespan expressed as a quadratic function of the order variables
(via linearisation of the completion-time recursion) + soft penalties that
force a total order (transitivity / antisymmetry already hard-coded by
using only i < j variables).
"""
from __future__ import annotations
import numpy as np
from itertools import combinations
from typing import Dict, List, Tuple
from .problem import Instance, evaluate_permutation


def pairwise_vars(n: int) -> List[Tuple[int, int]]:
    """List of (i,j) with i < j."""
    return list(combinations(range(n), 2))


def decode_permutation(bits: np.ndarray, job_ids: List[str]) -> List[str]:
    """
    Reconstruct a total order from pairwise precedence bits.
    bits[k] = 1 means job_ids[i] precedes job_ids[j] for the k-th pair (i<j).
    Uses topological sort; if the bits are inconsistent we repair by majority.
    """
    n = len(job_ids)
    pairs = pairwise_vars(n)
    # adjacency: edge u→v means u precedes v
    adj = {i: set() for i in range(n)}
    for k, (i, j) in enumerate(pairs):
        if bits[k] > 0.5:
            adj[i].add(j)
        else:
            adj[j].add(i)
    # Kahn topological sort with preference for lower index on ties
    indeg = {i: 0 for i in range(n)}
    for u in adj:
        for v in adj[u]:
            indeg[v] += 1
    order = []
    ready = sorted([i for i in range(n) if indeg[i] == 0])
    while ready:
        u = ready.pop(0)
        order.append(u)
        for v in sorted(adj[u]):
            indeg[v] -= 1
            if indeg[v] == 0:
                ready.append(v)
                ready.sort()
    if len(order) < n:  # cycle – fall back to identity
        order = list(range(n))
    return [job_ids[i] for i in order]


def build_permutation_qubo(inst: Instance, penalty: float = 50.0) -> Tuple[np.ndarray, np.ndarray, List[Tuple[int, int]]]:
    """
    Construct Q (upper-triangular) and linear vector L such that
        E(x) = x^T Q x + L^T x
    approximates the makespan of the decoded permutation.
    Because the search space is tiny we can evaluate the true makespan
    for every bit-string and fit a QUBO that exactly matches it on the
    feasible (transitive) points; on infeasible points we add a large
    penalty.  This yields a *correct* QUBO with the absolute minimum
    number of variables.
    """
    n = inst.n_jobs
    pairs = pairwise_vars(n)
    n_vars = len(pairs)
    job_ids = [j.id for j in inst.jobs]

    # Enumerate all 2^{n_vars} assignments.
    # decode_permutation always returns a valid total order, so every
    # bit-string is mapped to a feasible schedule; the energy is exactly
    # the makespan of that schedule.  This yields a QUBO whose ground
    # state(s) are optimal permutations.
    energies = {}
    for mask in range(1 << n_vars):
        bits = np.array([(mask >> k) & 1 for k in range(n_vars)], dtype=float)
        perm = decode_permutation(bits, job_ids)
        ms, _ = evaluate_permutation(inst, perm)
        energies[mask] = float(ms)

    # Fit a QUBO that reproduces these energies exactly.
    # Because x_i^2 = x_i for binary variables we only need:
    #   E = offset + sum_i L_i x_i + sum_{i < j} Q_{ij} x_i x_j
    # Design matrix columns: 1 | x_i | x_i x_j (i<j)
    A = []
    b = []
    for mask in range(1 << n_vars):
        bits = [(mask >> k) & 1 for k in range(n_vars)]
        row = [1.0]
        for i in range(n_vars):
            row.append(float(bits[i]))
        for i in range(n_vars):
            for j in range(i + 1, n_vars):
                row.append(float(bits[i] * bits[j]))
        A.append(row)
        b.append(energies[mask])
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    # exact solve (square / over-determined but full rank for n_vars <= 3)
    coef, residuals, rank, _ = np.linalg.lstsq(A, b, rcond=None)

    L = np.zeros(n_vars)
    Q = np.zeros((n_vars, n_vars))
    offset = float(coef[0])
    idx = 1
    for i in range(n_vars):
        L[i] = float(coef[idx])
        idx += 1
    for i in range(n_vars):
        for j in range(i + 1, n_vars):
            Q[i, j] = float(coef[idx])
            idx += 1
    return Q, L, pairs, offset, energies


def qubo_energy(x: np.ndarray, Q: np.ndarray, L: np.ndarray, offset: float = 0.0) -> float:
    return float(x @ Q @ x + L @ x + offset)


def qubo_to_ising(Q: np.ndarray, L: np.ndarray, offset: float = 0.0):
    """Standard x = (1-z)/2 conversion → Ising h, J, const."""
    n = len(L)
    h = np.zeros(n)
    J = np.zeros((n, n))
    const = offset
    for i in range(n):
        h[i] -= 0.5 * L[i]
        const += 0.5 * L[i]
        for j in range(i + 1, n):
            J[i, j] = 0.25 * Q[i, j]
            h[i] -= 0.25 * Q[i, j]
            h[j] -= 0.25 * Q[i, j]
            const += 0.25 * Q[i, j]
        # diagonal of Q already folded into L
    return h, J, const


if __name__ == "__main__":
    from .problem import load_instances
    insts = load_instances()
    for name, inst in insts.items():
        Q, L, pairs, off, energies = build_permutation_qubo(inst)
        print(f"\n{name}: {len(pairs)} qubits/variables")
        print("pairs:", pairs)
        print("Q =\n", Q)
        print("L =", L)
        print("offset =", off)
        # verify that the QUBO reproduces the true energies
        n_vars = len(pairs)
        max_err = 0.0
        for mask, true_e in energies.items():
            x = np.array([(mask >> k) & 1 for k in range(n_vars)], dtype=float)
            e = qubo_energy(x, Q, L, off)
            max_err = max(max_err, abs(e - true_e))
        print(f"max reconstruction error = {max_err:.2e}")
