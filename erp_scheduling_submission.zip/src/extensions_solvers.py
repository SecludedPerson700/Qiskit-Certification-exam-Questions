"""
Quantum + classical solvers for Stage-2 extended objectives
(tardiness, setups) using the same warm-start CVaR / LR / PCE stack.
"""
from __future__ import annotations
import numpy as np
from typing import Dict, List, Tuple
from scipy.optimize import minimize
import time

from qiskit import QuantumCircuit
from qiskit.circuit.library import efficient_su2
from qiskit.quantum_info import SparsePauliOp
from qiskit_aer.primitives import EstimatorV2 as AerEstimator, SamplerV2 as AerSampler

from .problem import Instance, exact_optimum, greedy_baseline, evaluate_permutation, all_permutations
from .qubo import qubo_to_ising, decode_permutation, qubo_energy
from .extensions_data import (
    DUE_DATES_3X3, DUE_DATES_2X2,
    makespan_and_tardiness, total_tardiness, job_completion_times,
    default_setups_3x3, evaluate_permutation_with_setups,
    evaluate_with_two_mills,
)
from .extensions_qubo import build_tardiness_qubo, build_setup_qubo
from .quantum_solvers import (
    warm_start_angles, qaoa_circuit_with_params,
    sample_circuit, counts_to_best, cvar_from_counts,
)


def _greedy_bits(inst: Instance, pairs, energy_fn) -> np.ndarray:
    """Pick the permutation with best classical energy among all perms, encode as bits."""
    job_ids = [j.id for j in inst.jobs]
    best_e, best_perm = 1e18, job_ids
    for perm in all_permutations(inst):
        e = energy_fn(perm)
        if e < best_e:
            best_e, best_perm = e, perm
    pos = {jid: i for i, jid in enumerate(best_perm)}
    x0 = np.zeros(len(pairs))
    for k, (i, j) in enumerate(pairs):
        x0[k] = 1.0 if pos[job_ids[i]] < pos[job_ids[j]] else 0.0
    return x0, best_perm, best_e


def solve_extended_cvar(
    inst: Instance,
    Q, L, pairs, offset,
    energy_eval_perm,  # perm -> scalar (true objective)
    p: int = 1,
    alpha: float = 0.25,
    shots: int = 512,
    maxiter: int = 30,
    seed: int = 7,
) -> Dict:
    np.random.seed(seed)
    n_vars = len(pairs)
    h, J, const = qubo_to_ising(Q, L, offset)
    job_ids = [j.id for j in inst.jobs]

    def energy_fn(x):
        return qubo_energy(x, Q, L, offset)

    x0, g_perm, g_e = _greedy_bits(inst, pairs, energy_eval_perm)

    def objective(params):
        gamma, beta = params
        qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
        counts = sample_circuit(qc, shots=shots)
        return cvar_from_counts(counts, n_vars, energy_fn, alpha)

    t0 = time.time()
    res = minimize(objective, np.array([0.5, 0.5]), method="COBYLA",
                   options={"maxiter": maxiter})
    t_opt = time.time() - t0
    gamma, beta = res.x
    qc = qaoa_circuit_with_params(h, J, x0, gamma, beta, p)
    counts = sample_circuit(qc, shots=shots * 2)
    best_x, best_e = counts_to_best(counts, n_vars, energy_fn)
    perm = decode_permutation(best_x, job_ids)
    true_obj = energy_eval_perm(perm)
    return {
        "method": "Warm-start CVaR-QAOA (extended)",
        "n_qubits": n_vars,
        "perm": perm,
        "qubo_energy": best_e,
        "true_objective": true_obj,
        "opt_time": t_opt,
        "params": {"gamma": float(gamma), "beta": float(beta)},
        "seed": seed,
        "greedy_perm": g_perm,
        "greedy_obj": g_e,
    }


# ---------------------------------------------------------------------------
# Exact reference for extended objectives
# ---------------------------------------------------------------------------
def exact_tardiness_optimum(inst: Instance, due: Dict[str, int], lambda_tard: float = 1.0):
    best = None
    for perm in all_permutations(inst):
        ms, tard, sched = makespan_and_tardiness(inst, perm, due)
        obj = ms + lambda_tard * tard
        if best is None or obj < best[0]:
            best = (obj, ms, tard, perm, sched)
    return best  # obj, ms, tard, perm, sched


def exact_setup_optimum(inst: Instance, setups):
    best = None
    for perm in all_permutations(inst):
        ms, sched = evaluate_permutation_with_setups(inst, perm, setups)
        if best is None or ms < best[0]:
            best = (ms, perm, sched)
    return best


# ---------------------------------------------------------------------------
# High-level runners
# ---------------------------------------------------------------------------
def run_tardiness_extension(lambda_tard: float = 1.0, seeds: List[int] = None) -> List[Dict]:
    if seeds is None:
        seeds = [7, 11, 13]
    inst = load_instances_local()["3x3"]
    due = DUE_DATES_3X3
    Q, L, pairs, offset, energies = build_tardiness_qubo(inst, due, lambda_tard)

    def energy_eval_perm(perm):
        ms, tard, _ = makespan_and_tardiness(inst, perm, due)
        return ms + lambda_tard * tard

    exact = exact_tardiness_optimum(inst, due, lambda_tard)
    rows = [{
        "extension": "tardiness",
        "method": "Exact",
        "seed": None,
        "obj": exact[0],
        "makespan": exact[1],
        "tardiness": exact[2],
        "perm": exact[3],
        "n_qubits": 0,
        "gap": 0,
    }]
    for s in seeds:
        r = solve_extended_cvar(inst, Q, L, pairs, offset, energy_eval_perm, seed=s)
        ms, tard, sched = makespan_and_tardiness(inst, r["perm"], due)
        rows.append({
            "extension": "tardiness",
            "method": "CVaR-QAOA",
            "seed": s,
            "obj": ms + lambda_tard * tard,
            "makespan": ms,
            "tardiness": tard,
            "perm": r["perm"],
            "n_qubits": r["n_qubits"],
            "gap": (ms + lambda_tard * tard) - exact[0],
            "opt_time": r["opt_time"],
        })
    return rows, exact


def run_setup_extension(seeds: List[int] = None) -> List[Dict]:
    if seeds is None:
        seeds = [7, 11, 13]
    inst = load_instances_local()["3x3"]
    setups = default_setups_3x3()
    Q, L, pairs, offset, energies = build_setup_qubo(inst, setups)

    def energy_eval_perm(perm):
        ms, _ = evaluate_permutation_with_setups(inst, perm, setups)
        return ms

    exact = exact_setup_optimum(inst, setups)
    rows = [{
        "extension": "setups",
        "method": "Exact",
        "seed": None,
        "obj": exact[0],
        "makespan": exact[0],
        "perm": exact[1],
        "n_qubits": 0,
        "gap": 0,
    }]
    for s in seeds:
        r = solve_extended_cvar(inst, Q, L, pairs, offset, energy_eval_perm, seed=s)
        ms, sched = evaluate_permutation_with_setups(inst, r["perm"], setups)
        rows.append({
            "extension": "setups",
            "method": "CVaR-QAOA",
            "seed": s,
            "obj": ms,
            "makespan": ms,
            "perm": r["perm"],
            "n_qubits": r["n_qubits"],
            "gap": ms - exact[0],
            "opt_time": r["opt_time"],
        })
    return rows, exact


def run_second_mill_analysis() -> Dict:
    """
    Functional scaling: cost-benefit of a second milling machine.
    Compare best single-mill makespan vs dual-mill makespan under same perms.
    """
    from .problem import load_instances
    inst = load_instances()["3x3"]
    single = []
    dual = []
    for perm in all_permutations(inst):
        ms1, _ = evaluate_permutation(inst, perm)
        ms2, _ = evaluate_with_two_mills(inst, perm)
        single.append((ms1, perm))
        dual.append((ms2, perm))
    best_single = min(single, key=lambda t: t[0])
    best_dual = min(dual, key=lambda t: t[0])
    return {
        "best_single_mill": {"makespan": best_single[0], "perm": best_single[1]},
        "best_dual_mill": {"makespan": best_dual[0], "perm": best_dual[1]},
        "improvement_hours": best_single[0] - best_dual[0],
        "note": "If mill capital cost / horizon < improvement, second mill pays off.",
    }


def load_instances_local():
    from .problem import load_instances
    return load_instances()
