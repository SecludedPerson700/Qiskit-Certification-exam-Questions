"""
ERP Flow-Shop Scheduling – problem data & classical evaluation
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import json, os

# ---------------------------------------------------------------------------
# Instance definitions (exactly as given in the challenge)
# ---------------------------------------------------------------------------
INSTANCE_2X2 = {
    "problem": "erp_scheduling",
    "jobs": [
        {"id": "Z1", "operations": [
            {"machine": "T", "duration": 2},
            {"machine": "F", "duration": 1}]},
        {"id": "Z2", "operations": [
            {"machine": "T", "duration": 1},
            {"machine": "F", "duration": 2}]},
    ],
}

INSTANCE_3X3 = {
    "problem": "erp_scheduling",
    "jobs": [
        {"id": "Z1", "operations": [
            {"machine": "T", "duration": 2},
            {"machine": "F", "duration": 1},
            {"machine": "S", "duration": 2}]},
        {"id": "Z2", "operations": [
            {"machine": "T", "duration": 1},
            {"machine": "F", "duration": 2},
            {"machine": "S", "duration": 1}]},
        {"id": "Z3", "operations": [
            {"machine": "T", "duration": 2},
            {"machine": "F", "duration": 2},
            {"machine": "S", "duration": 1}]},
    ],
}

MACHINE_ORDER = {"T": 0, "F": 1, "S": 2}  # global technological order


@dataclass
class Operation:
    job: str
    machine: str
    duration: int
    index: int  # position in the job's route


@dataclass
class Job:
    id: str
    ops: List[Operation]


@dataclass
class Instance:
    name: str
    jobs: List[Job]
    machines: List[str]
    n_jobs: int
    n_machines: int

    @classmethod
    def from_dict(cls, name: str, data: dict) -> "Instance":
        jobs = []
        machines = []
        for j in data["jobs"]:
            ops = []
            for k, op in enumerate(j["operations"]):
                ops.append(Operation(j["id"], op["machine"], op["duration"], k))
                if op["machine"] not in machines:
                    machines.append(op["machine"])
            jobs.append(Job(j["id"], ops))
        # keep machines in technological order
        machines = sorted(machines, key=lambda m: MACHINE_ORDER.get(m, 99))
        return cls(name, jobs, machines, len(jobs), len(machines))


def load_instances() -> Dict[str, Instance]:
    return {
        "2x2": Instance.from_dict("2x2", INSTANCE_2X2),
        "3x3": Instance.from_dict("3x3", INSTANCE_3X3),
    }


# ---------------------------------------------------------------------------
# Classical makespan evaluation for a permutation schedule
# ---------------------------------------------------------------------------
def evaluate_permutation(inst: Instance, perm: List[str]) -> Tuple[int, List[dict]]:
    """
    Given a job order (same on every machine – optimal for flow-shop),
    compute start/end times and makespan with the classic recursive formula.
    """
    job_map = {j.id: j for j in inst.jobs}
    n = len(perm)
    m = inst.n_machines
    # C[i][k] = completion time of job perm[i] on machine k
    C = np.zeros((n, m), dtype=int)
    schedule = []

    for i, jid in enumerate(perm):
        job = job_map[jid]
        for k, op in enumerate(job.ops):
            # machine k processes this operation
            prev_job = C[i - 1, k] if i > 0 else 0
            prev_op = C[i, k - 1] if k > 0 else 0
            start = max(prev_job, prev_op)
            end = start + op.duration
            C[i, k] = end
            schedule.append({
                "job": jid,
                "machine": op.machine,
                "start": int(start),
                "end": int(end),
            })
    makespan = int(C[-1, -1])
    return makespan, schedule


def all_permutations(inst: Instance) -> List[List[str]]:
    from itertools import permutations
    ids = [j.id for j in inst.jobs]
    return [list(p) for p in permutations(ids)]


def exact_optimum(inst: Instance) -> Tuple[int, List[str], List[dict]]:
    """Brute-force optimal permutation (tiny search space)."""
    best_ms = float("inf")
    best_perm = None
    best_sched = None
    for p in all_permutations(inst):
        ms, sched = evaluate_permutation(inst, p)
        if ms < best_ms:
            best_ms = ms
            best_perm = p
            best_sched = sched
    return best_ms, best_perm, best_sched


# ---------------------------------------------------------------------------
# Greedy classical baseline (SPT / Johnson-like for 2 machines, NEH-style for 3)
# ---------------------------------------------------------------------------
def greedy_baseline(inst: Instance) -> Tuple[int, List[str], List[dict]]:
    """Simple constructive heuristic used as classical baseline."""
    if inst.n_machines == 2:
        # Johnson's rule for 2-machine flow-shop
        jobs = inst.jobs
        left, right = [], []
        for j in jobs:
            if j.ops[0].duration <= j.ops[1].duration:
                left.append(j.id)
            else:
                right.append(j.id)
        left.sort(key=lambda jid: next(j.ops[0].duration for j in jobs if j.id == jid))
        right.sort(key=lambda jid: next(j.ops[1].duration for j in jobs if j.id == jid), reverse=True)
        perm = left + right
    else:
        # NEH-like: sort by total processing time descending, insert optimally
        totals = {j.id: sum(o.duration for o in j.ops) for j in inst.jobs}
        ordered = sorted(totals, key=totals.get, reverse=True)
        perm = [ordered[0]]
        for jid in ordered[1:]:
            best_ms, best_pos = float("inf"), 0
            for pos in range(len(perm) + 1):
                cand = perm[:pos] + [jid] + perm[pos:]
                ms, _ = evaluate_permutation(inst, cand)
                if ms < best_ms:
                    best_ms, best_pos = ms, pos
            perm = perm[:best_pos] + [jid] + perm[best_pos:]
    ms, sched = evaluate_permutation(inst, perm)
    return ms, perm, sched


if __name__ == "__main__":
    insts = load_instances()
    for name, inst in insts.items():
        print(f"\n=== {name} ===")
        print(f"Jobs: {[j.id for j in inst.jobs]}, Machines: {inst.machines}")
        opt_ms, opt_perm, _ = exact_optimum(inst)
        print(f"Exact optimum makespan = {opt_ms}, perm = {opt_perm}")
        g_ms, g_perm, _ = greedy_baseline(inst)
        print(f"Greedy makespan = {g_ms}, perm = {g_perm}")
