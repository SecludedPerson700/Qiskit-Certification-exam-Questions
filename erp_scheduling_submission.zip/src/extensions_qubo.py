"""
QUBOs for Stage-2 extensions on the same pairwise-precedence variables.

  - Tardiness-augmented objective: E = makespan + λ * total_tardiness
  - Setup-augmented objective:     E = makespan_with_setups

Still only 3 binary variables for 3 jobs — extra realism costs **zero
extra qubits**; it only changes the energy table that the QUBO fits.
That is the point of the comparable-number argument.
"""
from __future__ import annotations
import numpy as np
from typing import Dict, List, Tuple
from itertools import combinations

from .problem import Instance, evaluate_permutation
from .qubo import pairwise_vars, decode_permutation, qubo_energy
from .extensions_data import (
    DUE_DATES_3X3, DUE_DATES_2X2,
    total_tardiness, makespan_and_tardiness,
    default_setups_3x3, evaluate_permutation_with_setups,
)


def _fit_qubo_from_energies(n_vars: int, energies: Dict[int, float]):
    """Least-squares QUBO fit (offset + linear + pairwise quadratic)."""
    A, b = [], []
    for mask in range(1 << n_vars):
        bits = [(mask >> k) & 1 for k in range(n_vars)]
        row = [1.0]
        for i in range(n_vars):
            row.append(float(bits[i]))
        for i in range(n_vars):
            for j in range(i + 1, n_vars):
                row.append(float(bits[i] * bits[j]))
        A.append(row)
        b.append(energies[mask])
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    coef, *_ = np.linalg.lstsq(A, b, rcond=None)
    L = np.zeros(n_vars)
    Q = np.zeros((n_vars, n_vars))
    offset = float(coef[0])
    idx = 1
    for i in range(n_vars):
        L[i] = float(coef[idx]); idx += 1
    for i in range(n_vars):
        for j in range(i + 1, n_vars):
            Q[i, j] = float(coef[idx]); idx += 1
    return Q, L, offset


def build_tardiness_qubo(
    inst: Instance,
    due: Dict[str, int],
    lambda_tard: float = 1.0,
) -> Tuple[np.ndarray, np.ndarray, list, float, Dict[int, float]]:
    """
    Energy = makespan + λ * total_tardiness  for every decoded permutation.
    Same #variables as baseline (1 or 3).
    """
    n = inst.n_jobs
    pairs = pairwise_vars(n)
    n_vars = len(pairs)
    job_ids = [j.id for j in inst.jobs]
    energies = {}
    for mask in range(1 << n_vars):
        bits = np.array([(mask >> k) & 1 for k in range(n_vars)], dtype=float)
        perm = decode_permutation(bits, job_ids)
        ms, tard, _ = makespan_and_tardiness(inst, perm, due)
        energies[mask] = float(ms + lambda_tard * tard)
    Q, L, offset = _fit_qubo_from_energies(n_vars, energies)
    return Q, L, pairs, offset, energies


def build_setup_qubo(
    inst: Instance,
    setups: Dict[Tuple[str, str, str], int],
) -> Tuple[np.ndarray, np.ndarray, list, float, Dict[int, float]]:
    """Energy = makespan under sequence-dependent setups. Same #variables."""
    n = inst.n_jobs
    pairs = pairwise_vars(n)
    n_vars = len(pairs)
    job_ids = [j.id for j in inst.jobs]
    energies = {}
    for mask in range(1 << n_vars):
        bits = np.array([(mask >> k) & 1 for k in range(n_vars)], dtype=float)
        perm = decode_permutation(bits, job_ids)
        ms, _ = evaluate_permutation_with_setups(inst, perm, setups)
        energies[mask] = float(ms)
    Q, L, offset = _fit_qubo_from_energies(n_vars, energies)
    return Q, L, pairs, offset, energies


def variable_cost_report() -> str:
    """Price of realism: variables in naive time-indexed vs ours."""
    lines = [
        "Price of realism (3 jobs × 3 machines, H=8):",
        "  Baseline makespan only     | time-indexed ~72 | pairwise 3",
        "  + due dates / tardiness    | time-indexed ~72 + soft penalties | pairwise 3 (same bits, new energy)",
        "  + sequence-dependent setups| time-indexed ~72 + O(n² m)       | pairwise 3 (same bits, new energy)",
        "  + both                     | still ~72+                      | pairwise 3",
        "",
        "Extra realism costs ZERO additional qubits in the pairwise encoding;",
        "it only changes the classical energy table that the QUBO interpolates.",
    ]
    return "\n".join(lines)
