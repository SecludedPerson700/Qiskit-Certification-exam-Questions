"""
Planner view: load schedules, print a human-readable plan, draw Gantt charts,
and export a planner PDF for the jury / production manager.
"""
from __future__ import annotations
import json
from pathlib import Path
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

ROOT = Path(__file__).resolve().parents[1]
SCHED_DIR = ROOT / "schedules"
OUT_DIR = ROOT / "results"
DOCS_DIR = ROOT / "docs"

COLORS = {"Z1": "#4C72B0", "Z2": "#DD8452", "Z3": "#55A868", "Z4": "#C44E52"}
MACHINE_ORDER = {"T": 0, "F": 1, "F2": 1.5, "S": 2}


def load_schedule(path: Path) -> dict:
    with open(path) as f:
        return json.load(f)


def print_plan(data: dict) -> None:
    """Console planner view."""
    print("=" * 64)
    print(f"  PLANNER VIEW  |  {data.get('instance', '?')}")
    print(f"  Method: {data.get('method', '?')}")
    print(f"  Makespan: {data.get('makespan', '?')} h")
    print("=" * 64)
    sched = data.get("schedule", [])
    # by machine
    by_m: Dict[str, List] = defaultdict(list)
    for s in sched:
        by_m[s["machine"]].append(s)
    machines = sorted(by_m.keys(), key=lambda m: MACHINE_ORDER.get(m, 99))
    print(f"\n{'Machine':<8} {'Job':<6} {'Start':>6} {'End':>6} {'Dur':>5}")
    print("-" * 40)
    for m in machines:
        ops = sorted(by_m[m], key=lambda x: x["start"])
        for s in ops:
            dur = s["end"] - s["start"]
            print(f"{m:<8} {s['job']:<6} {s['start']:>6} {s['end']:>6} {dur:>5}")
        print()
    # timeline bars (ASCII)
    ms = int(data.get("makespan", 0))
    print("Timeline (1 char ≈ 1 h):")
    for m in machines:
        ops = sorted(by_m[m], key=lambda x: x["start"])
        line = ["·"] * max(ms, 1)
        for s in ops:
            for t in range(s["start"], min(s["end"], ms)):
                line[t] = s["job"][-1]  # last char of job id
        print(f"  {m:<4} |{''.join(line)}|")
    print()


def gantt_figure(data: dict, ax=None, title_prefix: str = ""):
    """Draw a Gantt chart on ax (or create figure)."""
    sched = data["schedule"]
    machines = sorted({s["machine"] for s in sched}, key=lambda m: MACHINE_ORDER.get(m, 99))
    own = ax is None
    if own:
        fig, ax = plt.subplots(figsize=(9, 2.2 + 0.45 * len(machines)))
    else:
        fig = ax.figure
    ymap = {m: i for i, m in enumerate(machines)}
    for s in sched:
        color = COLORS.get(s["job"], "#888888")
        ax.barh(
            ymap[s["machine"]],
            s["end"] - s["start"],
            left=s["start"],
            height=0.55,
            color=color,
            edgecolor="black",
            linewidth=0.6,
        )
        ax.text(
            s["start"] + (s["end"] - s["start"]) / 2,
            ymap[s["machine"]],
            s["job"],
            ha="center",
            va="center",
            fontsize=9,
            color="white",
            fontweight="bold",
        )
    ax.set_yticks(list(ymap.values()))
    ax.set_yticklabels(machines)
    ax.set_xlabel("Time (hours)")
    ms = data.get("makespan", max(s["end"] for s in sched))
    ax.set_xlim(0, ms + 0.5)
    ax.set_title(
        f"{title_prefix}{data.get('instance', '')}  |  makespan = {ms} h  |  {data.get('method', '')}"
    )
    jobs = sorted({s["job"] for s in sched})
    handles = [mpatches.Patch(color=COLORS.get(j, "#888"), label=j) for j in jobs]
    ax.legend(handles=handles, loc="upper right", fontsize=8)
    ax.set_axisbelow(True)
    ax.grid(True, axis="x", alpha=0.3)
    if own:
        plt.tight_layout()
    return fig, ax


def save_gantt(data: dict, path: Path, title_prefix: str = "") -> Path:
    fig, _ = gantt_figure(data, title_prefix=title_prefix)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)
    return path


def results_summary_table() -> List[List[str]]:
    """Static summary table for planner PDF (from verified runs)."""
    return [
        ["Instance", "Method", "Makespan", "Qubits", "Optimal"],
        ["2×2", "Exact / Greedy", "4", "0", "Yes"],
        ["2×2", "CVaR-QAOA / LR-QAOA", "4", "1", "5/5"],
        ["3×3", "Exact / Greedy", "8", "0", "Yes"],
        ["3×3", "CVaR-QAOA / LR-QAOA", "8", "3", "5/5"],
        ["3×3", "PCE", "8", "2", "5/5"],
        ["3×3 + tardiness", "CVaR-QAOA", "obj=8", "3", "5/5"],
        ["3×3 + setups", "CVaR-QAOA", "10", "3", "5/5"],
    ]


def export_planner_pdf(
    schedule_paths: Optional[List[Path]] = None,
    out_pdf: Optional[Path] = None,
) -> Path:
    """Build a multi-page planner PDF with Gantt images and results tables."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
    from reportlab.lib import colors
    from reportlab.lib.colors import HexColor
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        Image, PageBreak, HRFlowable,
    )

    if schedule_paths is None:
        schedule_paths = [
            SCHED_DIR / "schedule_2x2.json",
            SCHED_DIR / "schedule_3x3.json",
        ]
    if out_pdf is None:
        out_pdf = DOCS_DIR / "Planner_View.pdf"
    out_pdf.parent.mkdir(parents=True, exist_ok=True)

    # render gantts
    gantt_paths = []
    plans = []
    for p in schedule_paths:
        if not p.exists():
            continue
        data = load_schedule(p)
        plans.append(data)
        gp = OUT_DIR / f"planner_gantt_{data.get('instance', p.stem)}.png"
        save_gantt(data, gp)
        gantt_paths.append(gp)

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name="TMain", fontName="Helvetica-Bold", fontSize=15,
        alignment=TA_CENTER, spaceAfter=8, leading=18,
    ))
    styles.add(ParagraphStyle(
        name="H1p", fontName="Helvetica-Bold", fontSize=12,
        spaceBefore=12, spaceAfter=6, textColor=HexColor("#1a1a1a"),
    ))
    styles.add(ParagraphStyle(
        name="BodyP", fontName="Helvetica", fontSize=9.5,
        leading=12.5, alignment=TA_JUSTIFY, spaceAfter=6,
    ))
    styles.add(ParagraphStyle(
        name="Small", fontName="Helvetica", fontSize=8.5,
        leading=11, spaceAfter=3,
    ))

    doc = SimpleDocTemplate(
        str(out_pdf), pagesize=A4,
        leftMargin=1.8*cm, rightMargin=1.8*cm,
        topMargin=1.6*cm, bottomMargin=1.6*cm,
    )
    story = []

    story.append(Paragraph("Production Planner View", styles["TMain"]))
    story.append(Paragraph(
        "MetalTech ERP Flow-Shop — Quantum-Optimised Schedules",
        ParagraphStyle("st", parent=styles["Normal"], alignment=TA_CENTER,
                       fontSize=10, textColor=HexColor("#555555"), spaceAfter=10),
    ))
    story.append(HRFlowable(width="100%", thickness=1, color=HexColor("#2c3e50")))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "This planner document shows the production schedules returned by the quantum hybrid "
        "solver (warm-start CVaR-QAOA), together with makespan, machine timelines, and a "
        "summary of all verified methods. Intended for the production manager and the jury.",
        styles["BodyP"],
    ))

    # results table
    story.append(Paragraph("1. Results scoreboard", styles["H1p"]))
    data_t = results_summary_table()
    t = Table(data_t, colWidths=[3.2*cm, 4.2*cm, 2.4*cm, 2.2*cm, 2.2*cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.4, HexColor("#cccccc")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, HexColor("#f0f4f8")]),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.35*cm))

    # each plan
    for i, (data, gp) in enumerate(zip(plans, gantt_paths)):
        story.append(Paragraph(
            f"{2+i}. Schedule — {data.get('instance', '')}",
            styles["H1p"],
        ))
        story.append(Paragraph(
            f"<b>Method:</b> {data.get('method')} &nbsp;&nbsp; "
            f"<b>Makespan:</b> {data.get('makespan')} h",
            styles["Small"],
        ))
        # operation table
        rows = [["Job", "Machine", "Start (h)", "End (h)", "Duration (h)"]]
        for s in sorted(data["schedule"], key=lambda x: (MACHINE_ORDER.get(x["machine"], 99), x["start"])):
            rows.append([
                s["job"], s["machine"],
                str(s["start"]), str(s["end"]),
                str(s["end"] - s["start"]),
            ])
        ot = Table(rows, colWidths=[2.5*cm, 2.5*cm, 2.8*cm, 2.8*cm, 3*cm])
        ot.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), HexColor("#34495e")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("GRID", (0, 0), (-1, -1), 0.35, HexColor("#bbb")),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, HexColor("#fafafa")]),
            ("TOPPADDING", (0, 0), (-1, -1), 3),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(ot)
        story.append(Spacer(1, 0.25*cm))
        if gp.exists():
            story.append(Image(str(gp), width=16*cm, height=4.2*cm))
        story.append(Spacer(1, 0.2*cm))

    story.append(Paragraph("Notes for the planner", styles["H1p"]))
    story.append(Paragraph(
        "• Both baseline schedules match the exact classical optimum (makespan 4 and 8).<br/>"
        "• Encoding uses 1 qubit (2×2) and 3 qubits / PCE 2 qubits (3×3) versus ~32 / ~72 "
        "time-indexed variables.<br/>"
        "• Stage-2 extensions (due dates, sequence-dependent setups) keep the same 3 variables "
        "and remain optimal under warm-start CVaR-QAOA.<br/>"
        "• No statistical quantum advantage at this size; the planner value is a compact, "
        "verified schedule ready for execution.",
        styles["BodyP"],
    ))

    doc.build(story)
    return out_pdf


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    paths = [
        SCHED_DIR / "schedule_2x2.json",
        SCHED_DIR / "schedule_3x3.json",
    ]
    for p in paths:
        if not p.exists():
            print(f"Missing {p}")
            continue
        data = load_schedule(p)
        print_plan(data)
        gp = OUT_DIR / f"planner_gantt_{data.get('instance', p.stem)}.png"
        save_gantt(data, gp)
        print(f"Gantt saved → {gp}\n")

    pdf = export_planner_pdf(paths)
    print(f"Planner PDF → {pdf}")


if __name__ == "__main__":
    main()
