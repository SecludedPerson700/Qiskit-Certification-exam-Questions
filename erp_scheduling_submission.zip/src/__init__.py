from .problem import load_instances, exact_optimum, greedy_baseline, evaluate_permutation
from .qubo import build_permutation_qubo

# quantum_solvers needs qiskit — import only when asked
def __getattr__(name):
    if name in (
        "solve_cvar_qaoa", "solve_lr_qaoa", "solve_pce",
        "classical_random_repair", "run_all_methods",
    ):
        from . import quantum_solvers
        return getattr(quantum_solvers, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
