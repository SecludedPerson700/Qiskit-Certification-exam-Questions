#!/usr/bin/env python3
"""
Stage-2 extensions runner:
  1. Due dates & tardiness
  2. Sequence-dependent setup times
  3. Second milling machine cost-benefit
  4. Variable-cost (price of realism) report
"""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

from src.extensions_qubo import variable_cost_report, build_tardiness_qubo, build_setup_qubo
from src.extensions_data import DUE_DATES_3X3, default_setups_3x3
from src.extensions_solvers import (
    run_tardiness_extension, run_setup_extension, run_second_mill_analysis,
    exact_tardiness_optimum, exact_setup_optimum,
)
from src.problem import load_instances

OUT = Path("/home/workdir/artifacts/erp_scheduling/results")
OUT.mkdir(parents=True, exist_ok=True)


def main():
    print("=" * 72)
    print("STAGE-2 EXTENSIONS — full verification")
    print("=" * 72)

    print("\n" + variable_cost_report())

    # ---- Tardiness ----
    print("\n" + "-" * 72)
    print("EXTENSION A: Due dates & tardiness (λ=1)")
    print("-" * 72)
    print(f"Due dates: {DUE_DATES_3X3}")
    tard_rows, tard_exact = run_tardiness_extension(lambda_tard=1.0, seeds=[7, 11, 13, 17, 19])
    print(f"Exact optimum: obj={tard_exact[0]}  makespan={tard_exact[1]}  "
          f"tardiness={tard_exact[2]}  perm={tard_exact[3]}")
    tdf = pd.DataFrame(tard_rows)
    print(tdf.groupby("method").agg(
        best_obj=("obj", "min"), mean_obj=("obj", "mean"),
        n_opt=("gap", lambda x: int((x == 0).sum())), n=("gap", "count"),
        qubits=("n_qubits", "first"),
    ).to_string())

    # ---- Setups ----
    print("\n" + "-" * 72)
    print("EXTENSION B: Sequence-dependent setup times")
    print("-" * 72)
    setups = default_setups_3x3()
    print(f"Non-zero setups: { {k:v for k,v in setups.items() if v>0} }")
    setup_rows, setup_exact = run_setup_extension(seeds=[7, 11, 13, 17, 19])
    print(f"Exact optimum: makespan={setup_exact[0]}  perm={setup_exact[1]}")
    sdf = pd.DataFrame(setup_rows)
    print(sdf.groupby("method").agg(
        best_obj=("obj", "min"), mean_obj=("obj", "mean"),
        n_opt=("gap", lambda x: int((x == 0).sum())), n=("gap", "count"),
        qubits=("n_qubits", "first"),
    ).to_string())

    # ---- Second mill ----
    print("\n" + "-" * 72)
    print("EXTENSION C: Second milling machine (functional scaling)")
    print("-" * 72)
    mill = run_second_mill_analysis()
    print(f"Best single-mill makespan: {mill['best_single_mill']}")
    print(f"Best dual-mill makespan:   {mill['best_dual_mill']}")
    print(f"Improvement: {mill['improvement_hours']} h")
    print(f"Note: {mill['note']}")

    # ---- Qubit counts for extended QUBOs ----
    print("\n" + "-" * 72)
    print("QUBIT COUNTS (extended models still use 3 pairwise vars)")
    print("-" * 72)
    inst = load_instances()["3x3"]
    Qt, Lt, pt, ot, _ = build_tardiness_qubo(inst, DUE_DATES_3X3)
    Qs, Ls, ps, os_, _ = build_setup_qubo(inst, setups)
    print(f"Tardiness QUBO variables: {len(pt)}")
    print(f"Setup QUBO variables:     {len(ps)}")
    print("Time-indexed equivalent stays ~72; we stay at 3.")

    # save
    out = {
        "tardiness": tard_rows,
        "setups": setup_rows,
        "second_mill": mill,
        "variable_cost": variable_cost_report(),
        "comparable_number_3x3": 3,
        "comparable_number_note": "Same 3 pairwise bits for baseline, tardiness, and setups",
    }
    path = OUT / "stage2_extensions_results.json"
    with open(path, "w") as f:
        json.dump(out, f, indent=2, default=str)
    print(f"\nSaved → {path}")

    # verdict
    print("\n" + "=" * 72)
    print("STAGE-2 EXTENSIONS VERDICT")
    print("=" * 72)
    t_ok = all(r["gap"] == 0 for r in tard_rows if r["method"] != "Exact")
    s_ok = all(r["gap"] == 0 for r in setup_rows if r["method"] != "Exact")
    print(f"Tardiness: CVaR-QAOA matches exact on all seeds? {t_ok}")
    print(f"Setups:    CVaR-QAOA matches exact on all seeds? {s_ok}")
    print(f"Second mill improvement: {mill['improvement_hours']} h")
    print(f"Extra qubits for realism: 0 (still 3 variables)")
    if t_ok and s_ok:
        print("\nCONFIRMED: due-dates and sequence-dependent setups fully formulated,")
        print("solved with warm-start CVaR-QAOA, verified vs exact, zero extra qubits.")
    print("DONE.")


if __name__ == "__main__":
    main()
