#!/usr/bin/env python3
"""Launch the production planner view (console + Gantt PNGs + PDF)."""
from src.planner import main

if __name__ == "__main__":
    main()
